DEBUG =
{
   INVINCIBLE: false,
   COLLISIONRADIUS: false,
   FPS: true
};
