DEBUG =
{
   INVINCIBLE: true,
   COLLISIONRADIUS: false,
   FPS: true
};
